document.getElementById('year').textContent=new Date().getFullYear();
const BTC_PLACEHOLDER='[BTC_PLACEHOLDER]';
const btcEl=document.getElementById('btc-address');
btcEl.textContent=BTC_PLACEHOLDER;
document.getElementById('copyBtcBtn').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(btcEl.textContent.trim());alert('Copied Bitcoin address')}catch(e){alert('Copy manually')}});
const uploadForm=document.getElementById('uploadForm');
const uploadStatus=document.getElementById('uploadStatus');
uploadForm.addEventListener('submit',async(e)=>{e.preventDefault();
const fileInput=document.getElementById('proof');
const name=document.getElementById('name').value.trim();
const email=document.getElementById('email').value.trim();
if(!fileInput.files.length){uploadStatus.textContent='Please choose a file to upload.';return;}
const formData=new FormData();
formData.append('proof',fileInput.files[0]);
formData.append('name',name);
formData.append('email',email);
uploadStatus.textContent='Uploading...';
try{const res=await fetch('/api/upload',{method:'POST',body:formData});
const data=await res.json();if(!res.ok)throw new Error(data.error||'Upload failed');
uploadStatus.innerHTML=`✅ Upload successful! File: <a href="${data.fileUrl}" target="_blank">${data.fileUrl}</a>`;
}catch(err){uploadStatus.textContent='Upload error: '+err.message;}
});
let selectedRating=0;
const stars=document.querySelectorAll('.star');
stars.forEach(s=>{s.addEventListener('click',()=>{selectedRating=Number(s.getAttribute('data-value'));
stars.forEach(st=>{st.textContent=Number(st.getAttribute('data-value'))<=selectedRating?'★':'☆';});});});
document.getElementById('submit-review-btn').addEventListener('click',()=>{const comment=document.getElementById('comment').value.trim();
if(!selectedRating){alert('Please select a star rating first');return;}
alert(`Thanks! You rated ${selectedRating} stars. Review: ${comment}`);
});